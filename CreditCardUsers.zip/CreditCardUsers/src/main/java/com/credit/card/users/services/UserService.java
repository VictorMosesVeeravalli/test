package com.credit.card.users.services;

import java.util.List;

import com.credit.card.users.model.UserDetailsRequest;
import com.credit.card.users.model.UserDto;

public interface UserService {
	
	List<UserDto> getUsers();
	UserDto getUserById(String userId);
	UserDto addUser(UserDetailsRequest addUser);
	UserDto updateUser(UserDetailsRequest addUser);
	UserDto deleteUser(String userId);
	
	

}
