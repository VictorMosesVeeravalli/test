package com.credit.card.users.entities;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="CreditUsers")
public class UsersEntity {
	
	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String userId;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private String email;
	@Column
	private String address;
	@Column
	private String mobilenumber;


}
