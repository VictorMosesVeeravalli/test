package com.credit.card.users.model;

import java.math.BigInteger;

import lombok.Data;

@Data
public class UserDto {
	
	private String userId;
	private String firstName;
	private String lastName;
	private String email;
	private String address;
	private String mobilenumber;
	private String message;

}
