package com.credit.card.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditCardUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditCardUsersApplication.class, args);
	}

}
