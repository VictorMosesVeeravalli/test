package com.credit.card.users.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MatchingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.credit.card.users.model.UserDetailsRequest;
import com.credit.card.users.model.UserDto;
import com.credit.card.users.model.UserDetailsResponse;
import com.credit.card.users.services.UserServiceImpl;

@RestController
@RequestMapping("/creditcardservice")
public class UserController {

	@Autowired
	UserServiceImpl userService;

	@GetMapping("/getusers")
	public ResponseEntity<List<UserDetailsResponse>> getUsers() {

		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		
		List<UserDto> userList=new ArrayList<UserDto>();
		
		userList=userService.getUsers();
		List<UserDetailsResponse> users=new ArrayList<UserDetailsResponse>();

		List<UserDetailsResponse> resp = userList
				  .stream()
				  .map(user -> mapper.map(user, UserDetailsResponse.class))
				  .collect(Collectors.toList());
		
		

		return ResponseEntity.status(HttpStatus.OK).body(resp);

	}
	
	@GetMapping("/getuserbyid/{userId}")
	public ResponseEntity<UserDetailsResponse> getUserById(@PathVariable("userId") String userId) {

		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		UserDto dto=new UserDto();
	
		
		dto=userService.getUserById(userId);
		UserDetailsResponse userResp = mapper.map(dto, UserDetailsResponse.class);
		
		

		return ResponseEntity.status(HttpStatus.OK).body(userResp);

	}


	@PostMapping("/adduser")
	public ResponseEntity<UserDetailsResponse> addUser(@RequestBody UserDetailsRequest userReq) {
		UserDto dto = new UserDto();

		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
	//	dto = userService.addUser(userReq);

		UserDetailsResponse resp = mapper.map(dto, UserDetailsResponse.class);

		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}

	@PostMapping("/deleteuser/{userid}")
	public ResponseEntity<UserDetailsResponse> deleteUser(@PathVariable("userid") String userId) {
		
		userService.deleteUser(userId);
		return null;

	}

	@PutMapping("/updateuser")
	public ResponseEntity<?> updateUser(@RequestBody UserDetailsRequest userReq) {
		UserDto dto = new UserDto();

		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		dto = userService.updateUser(userReq);

		UserDetailsResponse resp = mapper.map(dto, UserDetailsResponse.class);

		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}

	

}
