package com.credit.card.users.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="UserRequestPacket")
public class UserRequestEnitity {

	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String requestPacket;
	
}
