package com.credit.card.users.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.credit.card.users.entities.UsersEntity;
import com.credit.card.users.model.UserDetailsRequest;
import com.credit.card.users.model.UserDto;
import com.credit.card.users.model.UserDetailsResponse;
import com.credit.card.users.repositories.UsersRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UsersRepository userRepository;

	@Override
	public List<UserDto> getUsers() {
		
		UserDto userDto=new UserDto();
		System.out.println("in get Users");
		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		
		
		
		
		List<UsersEntity> userList=new ArrayList<UsersEntity>();
		List<UserDto> listUsers=new ArrayList<UserDto>();
		
		//userList=userRepository.findAll();
		
		List<UserDto> dtos = userList
				  .stream()
				  .map(user -> mapper.map(user, UserDto.class))
				  .collect(Collectors.toList());
		//mapper.map(userList, listUsers);
		
		
		return dtos;
	}

	@Override
	public UserDto addUser(UserDetailsRequest addUser) {
		// TODO Auto-generated method stub
		
		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		
		UsersEntity entity = mapper.map(addUser, UsersEntity.class);
		
		entity.setUserId(UUID.randomUUID().toString());
		//userRepository.save(entity);
		
		UserDto dto=	mapper.map(entity, UserDto.class);
		
		dto.setMessage("Successfully created User");
		dto.setUserId(entity.getUserId());
		dto.setFirstName(entity.getFirstName());
		dto.setLastName(entity.getLastName());
		dto.setEmail(entity.getEmail());
		dto.setMobilenumber(entity.getMobilenumber());
		dto.setAddress(entity.getAddress());
		
		return dto;
	}

	@Override
	public UserDto updateUser(UserDetailsRequest addUser) {
UserDto dto=new UserDto();
		
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		
		UsersEntity entity = mapper.map(addUser, UsersEntity.class);
		//userRepository.save(entity);
		
		dto.setMessage("Successfully created User");
		
		return dto;
	}

	@Override
	public UserDto deleteUser(String userId) {
		// TODO Auto-generated method stub
		
		//userRepository.deleteByUserId(userId);
		
		return null;
	}

	@Override
	public UserDto getUserById(String userId) {
		// TODO Auto-generated method stub
		UsersEntity entity=new UsersEntity();
		UserDto dto=new UserDto();
		ModelMapper mapper = new ModelMapper();
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		
	//	Optional<UsersEntity> user = userRepository.findByUserId(userId);
		
	/*
	 * if(user.isPresent()) { dto = mapper.map(user.get(), UserDto.class);
	 * dto.setMessage("Successfully fetched");
	 * 
	 * }
	 * 
	 * else { dto.setMessage("UserNotFound"); }
	 */
		
		
		return dto;
	}}
