package com.credit.card.users.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.credit.card.users.entities.UserRequestEnitity;
import com.credit.card.users.repositories.UsersRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Aspect
@Component
public class DBLoggerRequestPacket {
	
	@Autowired
	UsersRepository userRepository;

	
	
	@Pointcut(value="execution(* com.credit.card.users.controller.UserController.*(..) )")
	public void myPointcut() {
		
	}
	
	@Around("myPointcut()")
	public Object applicationLogger(ProceedingJoinPoint pjp) throws Throwable {
		ObjectMapper mapper = new ObjectMapper();
		String methodName = pjp.getSignature().getName();
		String className = pjp.getTarget().getClass().toString();
		Object[] array = pjp.getArgs();
		UserRequestEnitity req=new UserRequestEnitity();
		
		req.setRequestPacket(mapper.writeValueAsString(array));
		userRepository.save(req);
		
		Object object = pjp.proceed();
		
		return object;
	}

}
