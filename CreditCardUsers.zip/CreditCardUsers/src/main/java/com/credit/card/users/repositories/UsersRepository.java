package com.credit.card.users.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.credit.card.users.entities.UserRequestEnitity;
import com.credit.card.users.entities.UsersEntity;

@Repository
public interface UsersRepository extends JpaRepository<UserRequestEnitity, Long> {

	//Optional<UsersEntity> deleteByUserId(String userId);

	//Optional<UsersEntity> findByUserId(String userId);

	

}
